# Game Booster HD
Android 10+ (minSdk 29). Pakai Shizuku atau Root.

1. Upload isi folder ini ke repo GitHub (branch main).
2. Buka tab Actions -> Build APK -> tunggu hijau.
3. Unduh artifact "GameBoosterHD-apk" (isinya zip berisi app-debug.apk).
