package com.gamebooster.hd

import android.content.Context
import android.os.Build

data class Profile(val name: String, val scale: Int)

object Booster {
    val profiles = listOf(
        Profile("Kualitas Maksimal", 100),
        Profile("Seimbang", 85),
        Profile("FPS Tinggi", 70)
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("booster", Context.MODE_PRIVATE)

    private fun physicalSize(): Pair<Int, Int>? {
        val m = Regex("Physical size: (\\d+)x(\\d+)").find(Shell.run("wm size")) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    private fun physicalDensity(): Int? {
        val m = Regex("Physical density: (\\d+)").find(Shell.run("wm density")) ?: return null
        return m.groupValues[1].toInt()
    }

    private fun even(v: Int) = if (v % 2 == 0) v else v + 1

    fun apply(ctx: Context, pkg: String, p: Profile, maxHz: Int): String {
        val log = StringBuilder()
        val pr = prefs(ctx)

        // Simpan nilai asli sekali saja
        if (!pr.getBoolean("boosted", false)) {
            val e = pr.edit()
            e.putString("min_hz", Shell.run("settings get system min_refresh_rate"))
            e.putString("peak_hz", Shell.run("settings get system peak_refresh_rate"))
            if (Shell.mode == Mode.ROOT) {
                e.putString("gov", Shell.run("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"))
            }
            e.putBoolean("boosted", true).apply()
        }

        // 1) Resolusi + density (berlaku untuk seluruh layar)
        if (p.scale < 100) {
            val size = physicalSize()
            val dens = physicalDensity()
            if (size != null && dens != null) {
                val w = even(size.first * p.scale / 100)
                val h = even(size.second * p.scale / 100)
                val d = dens * p.scale / 100
                Shell.run("wm size ${w}x$h")
                Shell.run("wm density $d")
                log.append("Resolusi ${w}x$h, density $d\n")
            } else log.append("Gagal baca ukuran layar\n")
        } else {
            Shell.run("wm size reset")
            Shell.run("wm density reset")
            log.append("Resolusi asli\n")
        }

        // 2) Refresh rate tertinggi
        if (maxHz > 0) {
            Shell.run("settings put system min_refresh_rate $maxHz")
            Shell.run("settings put system peak_refresh_rate $maxHz")
            log.append("Refresh rate $maxHz Hz\n")
        }

        // 3) Bersihkan proses latar belakang
        Shell.run("am kill-all")
        log.append("Proses latar dibersihkan\n")

        // 4) Game mode performa (Android 12+)
        if (Build.VERSION.SDK_INT >= 31) {
            Shell.run("cmd game mode performance $pkg")
            log.append("Game mode: performance\n")
        }

        // 5) Khusus root: governor CPU
        if (Shell.mode == Mode.ROOT) {
            Shell.run("for c in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do echo performance > \$c; done")
            log.append("CPU governor: performance\n")
        }
        return log.toString().trim()
    }

    fun restore(ctx: Context, pkg: String?): String {
        val pr = prefs(ctx)
        Shell.run("wm size reset")
        Shell.run("wm density reset")

        for ((key, name) in listOf("min_hz" to "min_refresh_rate", "peak_hz" to "peak_refresh_rate")) {
            val v = pr.getString(key, null)
            if (v == null || v == "null" || v.isBlank() || v.startsWith("ERR")) {
                Shell.run("settings delete system $name")
            } else {
                Shell.run("settings put system $name $v")
            }
        }
        if (Build.VERSION.SDK_INT >= 31 && pkg != null) {
            Shell.run("cmd game mode standard $pkg")
        }
        if (Shell.mode == Mode.ROOT) {
            val g = pr.getString("gov", null)
            if (!g.isNullOrBlank() && !g.startsWith("ERR")) {
                Shell.run("for c in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_governor; do echo $g > \$c; done")
            }
        }
        pr.edit().putBoolean("boosted", false).apply()
        return "Pengaturan dikembalikan normal"
    }
}
