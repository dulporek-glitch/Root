package com.gamebooster.hd

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvSelected: TextView
    private lateinit var tvLog: TextView
    private lateinit var rg: RadioGroup
    private var selected: GameItem? = null

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) Shell.mode = Mode.SHIZUKU
        runOnUiThread { updateStatus() }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener {
        if (Shell.shizukuReady()) Shell.mode = Mode.SHIZUKU
        runOnUiThread { updateStatus() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvSelected = findViewById(R.id.tvSelected)
        tvLog = findViewById(R.id.tvLog)
        rg = findViewById(R.id.rgProfile)

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)

        findViewById<Button>(R.id.btnAccess).setOnClickListener { requestAccess() }
        findViewById<Button>(R.id.btnStart).setOnClickListener { startBoost() }
        findViewById<Button>(R.id.btnRestore).setOnClickListener { restore() }

        loadGames()
        updateStatus()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        super.onDestroy()
    }

    private fun updateStatus() {
        tvStatus.text = when (Shell.mode) {
            Mode.SHIZUKU -> "Status: Shizuku aktif ✔"
            Mode.ROOT -> "Status: Root aktif ✔"
            Mode.NONE -> "Status: belum ada izin"
        }
    }

    private fun requestAccess() {
        thread {
            try {
                if (Shizuku.pingBinder()) {
                    if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                        Shell.mode = Mode.SHIZUKU
                    } else {
                        Shizuku.requestPermission(100)
                        return@thread
                    }
                } else if (Shell.rootReady()) {
                    Shell.mode = Mode.ROOT
                } else {
                    toast("Shizuku belum jalan dan root tidak ditemukan. Jalankan Shizuku dulu.")
                }
            } catch (e: Throwable) {
                toast("Error: ${e.message}")
            }
            runOnUiThread { updateStatus() }
        }
    }

    private fun loadGames() {
        thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val ai = it.activityInfo.applicationInfo
                    GameItem(
                        it.loadLabel(pm).toString(),
                        it.activityInfo.packageName,
                        it.loadIcon(pm),
                        ai.category == ApplicationInfo.CATEGORY_GAME
                    )
                }
                .distinctBy { it.pkg }
                .sortedWith(compareByDescending<GameItem> { it.isGame }.thenBy { it.label.lowercase() })

            runOnUiThread {
                val rv = findViewById<RecyclerView>(R.id.rvGames)
                rv.layoutManager = LinearLayoutManager(this)
                rv.adapter = GameAdapter(list) {
                    selected = it
                    tvSelected.text = "Game: ${it.label}"
                }
            }
        }
    }

    private fun currentProfile(): Profile = when (rg.checkedRadioButtonId) {
        R.id.rbBalanced -> Booster.profiles[1]
        R.id.rbFps -> Booster.profiles[2]
        else -> Booster.profiles[0]
    }

    @Suppress("DEPRECATION")
    private fun maxRefreshRate(): Int = try {
        windowManager.defaultDisplay.supportedModes.maxOf { it.refreshRate }.toInt()
    } catch (e: Throwable) {
        0
    }

    private fun startBoost() {
        val game = selected
        if (Shell.mode == Mode.NONE) return toast("Beri izin dulu (Shizuku / Root)")
        if (game == null) return toast("Pilih game dulu")
        val profile = currentProfile()
        val hz = maxRefreshRate()
        thread {
            val log = Booster.apply(this, game.pkg, profile, hz)
            runOnUiThread {
                tvLog.text = log
                packageManager.getLaunchIntentForPackage(game.pkg)?.let { startActivity(it) }
            }
        }
    }

    private fun restore() {
        if (Shell.mode == Mode.NONE) return toast("Beri izin dulu (Shizuku / Root)")
        val pkg = selected?.pkg
        thread {
            val log = Booster.restore(this, pkg)
            runOnUiThread { tvLog.text = log }
        }
    }

    private fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}
