package com.gamebooster.hd

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

enum class Mode { NONE, ROOT, SHIZUKU }

object Shell {
    @Volatile
    var mode: Mode = Mode.NONE

    fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun rootReady(): Boolean = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.contains("uid=0")
    } catch (e: Throwable) {
        false
    }

    /** Jalankan perintah shell. Panggil dari thread background. */
    fun run(cmd: String): String {
        val full = "($cmd) 2>&1"
        return try {
            val p: Process = when (mode) {
                Mode.SHIZUKU -> Shizuku.newProcess(arrayOf("sh", "-c", full), null, null)
                Mode.ROOT -> Runtime.getRuntime().exec(arrayOf("su", "-c", full))
                Mode.NONE -> return "ERR: izin belum diberikan"
            }
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.trim()
        } catch (e: Throwable) {
            "ERR: ${e.message}"
        }
    }
}
